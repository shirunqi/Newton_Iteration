#pragma once

#include <cmath>

class CEquation
{
public:
	CEquation();
	~CEquation();

public:
	double fx;                 // ����ֵ

public:
	double fn_fx(double x);    // ����ⷽ��
};

