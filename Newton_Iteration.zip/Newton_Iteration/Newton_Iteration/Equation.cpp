#include "stdafx.h"
#include "Equation.h"


CEquation::CEquation()
{
}


CEquation::~CEquation()
{
}

double CEquation::fn_fx(double x)
{
	fx = 2 * pow(x, 3) - 4 * pow(x, 2) + 3 * x - 6;

	return fx;
}
